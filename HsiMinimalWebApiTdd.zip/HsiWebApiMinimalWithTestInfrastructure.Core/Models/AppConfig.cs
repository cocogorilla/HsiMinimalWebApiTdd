﻿namespace $safeprojectname$.Models
{
    public class AppConfig
    {
        public string ConnectionString { get; set; }
    }
}
