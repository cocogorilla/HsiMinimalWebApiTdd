﻿namespace $safeprojectname$.Models
{
    public class PingModel
    {
        public string Ping { get; set; }
    }

    public class PongModel
    {
        public string Pong { get; set; }
    }
}
